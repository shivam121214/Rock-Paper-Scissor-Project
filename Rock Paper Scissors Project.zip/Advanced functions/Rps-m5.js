let Score = JSON.parse(localStorage.getItem(`score`));
// If there is not previous stored value then it will be null and we will assign the default value to the Score obj. 
// So that it can be accessed later in the code.
if(Score === null){
    Score = {
        Win : 0,
        Lose : 0,
        Tie : 0
    };
}
//---------------------------------------------------------------------------------------------------------
        // Additional feature after model 2!!
            // Live ScoreBoard Updation.
            let scoreBoard = document.querySelector(`.js-live-score`); 
                function score_Board(){
                    scoreBoard.innerHTML=`Win:- ${Score.Win} &nbsp;&nbsp; Loses:- ${Score.Lose} &nbsp;&nbsp; Tie:- ${Score.Tie}`;
                }
        
            // Live Result.
            let liveResult = document.querySelector(`.js-live-result`);
                function live_result(Result){
                    liveResult.innerHTML=`${Result}`;
                }

            // Live Choices.
            let liveChoice = document.querySelector(`.js-live-choice`);
                function live_choice(Your_Move,ComputerMove){
//-------------------------------------------------------------------------------
        // Additional features after model 3!!
            // adding img on choice section             
                liveChoice.innerHTML =
                // `Your Move:-
                // <img class="resize" src="${Your_Move}.png">
                // <br>
                // Computer's move:-
                // <img class="resize" src="${ComputerMove}.png">`;
                `<div class="choice-container">
                    <div class="choice">
                        <p>Your Move:</p>
                        <img class="img-move" src="${Your_Move}.png" alt="${Your_Move}">
                    </div>
                    <div class="choice">
                        <p>Computer's Move:</p>
                        <img class="img-move" src="${ComputerMove}.png" alt="${ComputerMove}">
                    </div>
                </div>`;
                }
//--------------------------------------------------------------------------------         

//--------------------------------------------------------------------------------------------------------
function result(Your_Move){
    const rand_no = Math.random(); // gives a Random Number between 0 and 1
            let ComputerMove = ``;
            let Result =``;
            // Computer move assigning.
            if(0 <= rand_no && rand_no <= 1/3){
                ComputerMove= `Rock`;
            }
            else if(1/3 < rand_no && rand_no <= 2/3){
                ComputerMove= `Paper`;
            }
            else if(2/3< rand_no && rand_no < 1){
                ComputerMove= `Scissor`;
            }
            else{
                alert(`error val= ${rand_no}`);
            }
            
            // Comparing Moves.
            if(Your_Move === `Rock`){
                if(ComputerMove ===`Rock`){
                    Result= `Tie`;
                }
                else if(ComputerMove === `Paper`){
                    Result= `You Lose`;
                }
                else if(ComputerMove === `Scissor`){
                    Result= `You Win`;
                }   
            }
            else if(Your_Move === `Paper`){
                if(ComputerMove ===`Rock`){
                    Result= `You Win`;
                }
                else if(ComputerMove === `Paper`){
                    Result= `Tie`;
                }
                else if(ComputerMove === `Scissor`){
                    Result= `You Lose`;
                }   
            }
            else if(Your_Move === `Scissor`){
                if(ComputerMove ===`Rock`){
                    Result= `You Lose`;
                }
                else if(ComputerMove === `Paper`){
                    Result= `You Win`;
                }
                else if(ComputerMove === `Scissor`){
                    Result= `Tie`;
                }   
            }
            
            if(Result == `You Win`){
                Score.Win++;
            }
            else if(Result == `You Lose`){
                Score.Lose++;
            }
            else if(Result == `Tie`){
                Score.Tie++;
            }
            
            localStorage.setItem(`score`,JSON.stringify(Score)); // Used to store Score permanently. More info inside Ojects.js file.
            // Previous Feature!!
            // alert(`You Picked ${Choice}.    Computer Picked ${ComputerMove}.    ${Result}\nWins:- ${Score.Win} , Loses:- ${Score.Lose} , Tie:- ${Score.Tie}`);
//---------------------------------------------------------------------------------------------------------------------------
            // Additional feature after model 2 !! 
            score_Board();  // Calling function to update innerHTML
            live_choice(Your_Move,ComputerMove);
            live_result(Result);
            // Live ScoreBoard Updation.
//---------------------------------------------------------------------------------------------------------------------------            
}
function reset(){
    Score.Win=0;
    Score.Lose=0;
    Score.Tie=0;
    alert(`Score has been Reset\nWins:- ${Score.Win} , Loses:- ${Score.Lose} , Tie:- ${Score.Tie}`);
    localStorage.setItem(`score`,JSON.stringify(Score)); // Used to store Score permanently even after refresh.
    /*
    Here we added "localStorage.setItem(`score`,JSON.stringify(Score));" in the reset() also
    Because although the reset() function updates the in-memory Score object and the UI,
    it does not update the localStorage where the scores are being Stored.
    So when we refresh the page, the script runs: "let Score = JSON.parse(localStorage.getItem(`score`));"
    and it loads the old scores from localStorage, because we never actually updated them to reflect the reset.
    */
//---------------------------------------------------------------------------------------------------------------------------
   // Additional feature after model 2 !!
        score_Board();  // Calling function to update innerHTML
        liveChoice.innerHTML=``; // Used this to reset liveChoice to default
        liveResult.innerHTML=``; // Used this to reset liveResult to default
//---------------------------------------------------------------------------------------------------------------------------
}

//-------------------------------------------------------------------------------------------------------------------
function button_functions(){
    const autoplay=document.querySelector('.js-autoplay');
    if( autoplay.innerText == 'Auto play' ){
        autoplay.innerText= 'Stop play';
    } 
    else if(autoplay.innerText == 'Stop play'){
        autoplay.innerText= 'Auto play';
    }
}
let isAutoPlaying= false;
let intervalId;
function autoplay(){
    if(!isAutoPlaying){
        intervalId=setInterval(function(){
            const rand_no = Math.random();
     if(0 <= rand_no && rand_no <= 1/3){
                Your_Move= `Rock`;
            }
            else if(1/3 < rand_no && rand_no <= 2/3){
                Your_Move= `Paper`;
            }
            else if(2/3< rand_no && rand_no < 1){
                Your_Move= `Scissor`;
            }
            else{
                alert(`error val= ${rand_no}`);
            }
        result(Your_Move);
        console.log('playing');
    },2000);
    isAutoPlaying= true;
}
else{
    console.log('stoped playing');
    clearInterval(intervalId);  // used to stop the interval. more on this in advanced functions.
    isAutoPlaying= false;
}
}